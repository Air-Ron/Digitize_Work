function add_number(e) {
    if (isNumberKey(e)) {
      setTimeout(() => {
        var first_number = document.getElementById("text1").value !== "" ? parseInt(document.getElementById("text1").value) : 0;
        var second_number = document.getElementById("text2").value !== "" ? parseInt(document.getElementById("text2").value) : 0;
        var third_number = document.getElementById("text3").value !== "" ? parseInt(document.getElementById("text3").value) : 0;
        var fourth_number = document.getElementById("text4").value !== "" ? parseInt(document.getElementById("text4").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("result").value = result;
        var fifth_number = document.getElementById("text5").value !== "" ? parseInt(document.getElementById("text5").value) : 0;
        var sixth_number = document.getElementById("text6").value !== "" ? parseInt(document.getElementById("text6").value) : 0;
        var seventh_number = document.getElementById("text7").value !== "" ? parseInt(document.getElementById("text7").value) : 0;
        var eighth_number = document.getElementById("text8").value !== "" ? parseInt(document.getElementById("text8").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("result1").value = result;
        var fifth_number = document.getElementById("textq").value !== "" ? parseInt(document.getElementById("textq").value) : 0;
        var sixth_number = document.getElementById("textw").value !== "" ? parseInt(document.getElementById("textw").value) : 0;
        var seventh_number = document.getElementById("texte").value !== "" ? parseInt(document.getElementById("texte").value) : 0;
        var eighth_number = document.getElementById("textr").value !== "" ? parseInt(document.getElementById("textr").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("result2").value = result;


        var first_number = document.getElementById("t").value !== "" ? parseInt(document.getElementById("t").value) : 0;
        var second_number = document.getElementById("te").value !== "" ? parseInt(document.getElementById("te").value) : 0;
        var third_number = document.getElementById("tex").value !== "" ? parseInt(document.getElementById("tex").value) : 0;
        var fourth_number = document.getElementById("textt").value !== "" ? parseInt(document.getElementById("textt").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("result3").value = result;
        var fifth_number = document.getElementById("texx").value !== "" ? parseInt(document.getElementById("texx").value) : 0;
        var sixth_number = document.getElementById("tee").value !== "" ? parseInt(document.getElementById("tee").value) : 0;
        var seventh_number = document.getElementById("teex").value !== "" ? parseInt(document.getElementById("teex").value) : 0;
        var eighth_number = document.getElementById("texxt").value !== "" ? parseInt(document.getElementById("texxt").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("result4").value = result;
        var fifth_number = document.getElementById("texta").value !== "" ? parseInt(document.getElementById("texta").value) : 0;
        var sixth_number = document.getElementById("texts").value !== "" ? parseInt(document.getElementById("texts").value) : 0;
        var seventh_number = document.getElementById("textd").value !== "" ? parseInt(document.getElementById("textd").value) : 0;
        var eighth_number = document.getElementById("textf").value !== "" ? parseInt(document.getElementById("textf").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("result5").value = result;


        var first_number = document.getElementById("tttt").value !== "" ? parseInt(document.getElementById("tttt").value) : 0;
        var second_number = document.getElementById("eeee").value !== "" ? parseInt(document.getElementById("eeee").value) : 0;
        var third_number = document.getElementById("xxxx").value !== "" ? parseInt(document.getElementById("xxxx").value) : 0;
        var fourth_number = document.getElementById("qqqq").value !== "" ? parseInt(document.getElementById("qqqq").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("result6").value = result;
        var fifth_number = document.getElementById("1111").value !== "" ? parseInt(document.getElementById("1111").value) : 0;
        var sixth_number = document.getElementById("2222").value !== "" ? parseInt(document.getElementById("2222").value) : 0;
        var seventh_number = document.getElementById("3333").value !== "" ? parseInt(document.getElementById("3333").value) : 0;
        var eighth_number = document.getElementById("4444").value !== "" ? parseInt(document.getElementById("4444").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("result7").value = result;
        var fifth_number = document.getElementById("1").value !== "" ? parseInt(document.getElementById("1").value) : 0;
        var sixth_number = document.getElementById("2").value !== "" ? parseInt(document.getElementById("2").value) : 0;
        var seventh_number = document.getElementById("3").value !== "" ? parseInt(document.getElementById("3").value) : 0;
        var eighth_number = document.getElementById("4").value !== "" ? parseInt(document.getElementById("4").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("result8").value = result;


        var first_number = document.getElementById("11").value !== "" ? parseInt(document.getElementById("11").value) : 0;
        var second_number = document.getElementById("22").value !== "" ? parseInt(document.getElementById("22").value) : 0;
        var third_number = document.getElementById("33").value !== "" ? parseInt(document.getElementById("33").value) : 0;
        var fourth_number = document.getElementById("44").value !== "" ? parseInt(document.getElementById("44").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("result9").value = result;
        var fifth_number = document.getElementById("111").value !== "" ? parseInt(document.getElementById("111").value) : 0;
        var sixth_number = document.getElementById("222").value !== "" ? parseInt(document.getElementById("222").value) : 0;
        var seventh_number = document.getElementById("333").value !== "" ? parseInt(document.getElementById("333").value) : 0;
        var eighth_number = document.getElementById("444").value !== "" ? parseInt(document.getElementById("444").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resultt").value = result;
        var fifth_number = document.getElementById("12").value !== "" ? parseInt(document.getElementById("12").value) : 0;
        var sixth_number = document.getElementById("23").value !== "" ? parseInt(document.getElementById("23").value) : 0;
        var seventh_number = document.getElementById("34").value !== "" ? parseInt(document.getElementById("34").value) : 0;
        var eighth_number = document.getElementById("45").value !== "" ? parseInt(document.getElementById("45").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resultt1").value = result;


        var first_number = document.getElementById("1.1").value !== "" ? parseInt(document.getElementById("1.1").value) : 0;
        var second_number = document.getElementById("2.2").value !== "" ? parseInt(document.getElementById("2.2").value) : 0;
        var third_number = document.getElementById("3.3").value !== "" ? parseInt(document.getElementById("3.3").value) : 0;
        var fourth_number = document.getElementById("4.4").value !== "" ? parseInt(document.getElementById("4.4").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resultt2").value = result;
        var fifth_number = document.getElementById("11.1").value !== "" ? parseInt(document.getElementById("11.1").value) : 0;
        var sixth_number = document.getElementById("22.2").value !== "" ? parseInt(document.getElementById("22.2").value) : 0;
        var seventh_number = document.getElementById("33.3").value !== "" ? parseInt(document.getElementById("33.3").value) : 0;
        var eighth_number = document.getElementById("44.4").value !== "" ? parseInt(document.getElementById("44.4").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resultt3").value = result;
        var fifth_number = document.getElementById("1.2").value !== "" ? parseInt(document.getElementById("1.2").value) : 0;
        var sixth_number = document.getElementById("2.3").value !== "" ? parseInt(document.getElementById("2.3").value) : 0;
        var seventh_number = document.getElementById("3.4").value !== "" ? parseInt(document.getElementById("3.4").value) : 0;
        var eighth_number = document.getElementById("4.5").value !== "" ? parseInt(document.getElementById("4.5").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resultt4").value = result;


        var first_number = document.getElementById("1.11").value !== "" ? parseInt(document.getElementById("1.11").value) : 0;
        var second_number = document.getElementById("2.22").value !== "" ? parseInt(document.getElementById("2.22").value) : 0;
        var third_number = document.getElementById("3.33").value !== "" ? parseInt(document.getElementById("3.33").value) : 0;
        var fourth_number = document.getElementById("4.44").value !== "" ? parseInt(document.getElementById("4.44").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resultt5").value = result;
        var fifth_number = document.getElementById("11.11").value !== "" ? parseInt(document.getElementById("11.11").value) : 0;
        var sixth_number = document.getElementById("22.22").value !== "" ? parseInt(document.getElementById("22.22").value) : 0;
        var seventh_number = document.getElementById("33.33").value !== "" ? parseInt(document.getElementById("33.33").value) : 0;
        var eighth_number = document.getElementById("44.44").value !== "" ? parseInt(document.getElementById("44.44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resultt6").value = result;
        var fifth_number = document.getElementById("1.22").value !== "" ? parseInt(document.getElementById("1.22").value) : 0;
        var sixth_number = document.getElementById("2.33").value !== "" ? parseInt(document.getElementById("2.33").value) : 0;
        var seventh_number = document.getElementById("3.44").value !== "" ? parseInt(document.getElementById("3.44").value) : 0;
        var eighth_number = document.getElementById("4.55").value !== "" ? parseInt(document.getElementById("4.55").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resultt7").value = result;


        var first_number = document.getElementById("1.111").value !== "" ? parseInt(document.getElementById("1.111").value) : 0;
        var second_number = document.getElementById("2.222").value !== "" ? parseInt(document.getElementById("2.222").value) : 0;
        var third_number = document.getElementById("3.333").value !== "" ? parseInt(document.getElementById("3.333").value) : 0;
        var fourth_number = document.getElementById("4.444").value !== "" ? parseInt(document.getElementById("4.444").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resultt8").value = result;
        var fifth_number = document.getElementById("12.11").value !== "" ? parseInt(document.getElementById("12.11").value) : 0;
        var sixth_number = document.getElementById("23.22").value !== "" ? parseInt(document.getElementById("23.22").value) : 0;
        var seventh_number = document.getElementById("34.33").value !== "" ? parseInt(document.getElementById("34.33").value) : 0;
        var eighth_number = document.getElementById("45.44").value !== "" ? parseInt(document.getElementById("45.44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resultt9").value = result;
        var fifth_number = document.getElementById("1.222").value !== "" ? parseInt(document.getElementById("1.222").value) : 0;
        var sixth_number = document.getElementById("2.333").value !== "" ? parseInt(document.getElementById("2.333").value) : 0;
        var seventh_number = document.getElementById("3.444").value !== "" ? parseInt(document.getElementById("3.444").value) : 0;
        var eighth_number = document.getElementById("4.555").value !== "" ? parseInt(document.getElementById("4.555").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resullt").value = result;


        var first_number = document.getElementById("a").value !== "" ? parseInt(document.getElementById("a").value) : 0;
        var second_number = document.getElementById("b").value !== "" ? parseInt(document.getElementById("b").value) : 0;
        var third_number = document.getElementById("c").value !== "" ? parseInt(document.getElementById("c").value) : 0;
        var fourth_number = document.getElementById("d").value !== "" ? parseInt(document.getElementById("d").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resullt1").value = result;
        var fifth_number = document.getElementById("e").value !== "" ? parseInt(document.getElementById("e").value) : 0;
        var sixth_number = document.getElementById("f").value !== "" ? parseInt(document.getElementById("f").value) : 0;
        var seventh_number = document.getElementById("g").value !== "" ? parseInt(document.getElementById("g").value) : 0;
        var eighth_number = document.getElementById("h").value !== "" ? parseInt(document.getElementById("h").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resullt2").value = result;
        var fifth_number = document.getElementById("i").value !== "" ? parseInt(document.getElementById("i").value) : 0;
        var sixth_number = document.getElementById("j").value !== "" ? parseInt(document.getElementById("j").value) : 0;
        var seventh_number = document.getElementById("k").value !== "" ? parseInt(document.getElementById("k").value) : 0;
        var eighth_number = document.getElementById("l").value !== "" ? parseInt(document.getElementById("l").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resullt3").value = result;


        var first_number = document.getElementById("a1").value !== "" ? parseInt(document.getElementById("a1").value) : 0;
        var second_number = document.getElementById("b2").value !== "" ? parseInt(document.getElementById("b2").value) : 0;
        var third_number = document.getElementById("c3").value !== "" ? parseInt(document.getElementById("c3").value) : 0;
        var fourth_number = document.getElementById("d4").value !== "" ? parseInt(document.getElementById("d4").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resullt4").value = result;
        var fifth_number = document.getElementById("e1").value !== "" ? parseInt(document.getElementById("e1").value) : 0;
        var sixth_number = document.getElementById("f2").value !== "" ? parseInt(document.getElementById("f2").value) : 0;
        var seventh_number = document.getElementById("g3").value !== "" ? parseInt(document.getElementById("g3").value) : 0;
        var eighth_number = document.getElementById("h4").value !== "" ? parseInt(document.getElementById("h4").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resullt5").value = result;
        var fifth_number = document.getElementById("i1").value !== "" ? parseInt(document.getElementById("i1").value) : 0;
        var sixth_number = document.getElementById("j2").value !== "" ? parseInt(document.getElementById("j2").value) : 0;
        var seventh_number = document.getElementById("k3").value !== "" ? parseInt(document.getElementById("k3").value) : 0;
        var eighth_number = document.getElementById("l4").value !== "" ? parseInt(document.getElementById("l4").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resullt6").value = result;


        var first_number = document.getElementById("a11").value !== "" ? parseInt(document.getElementById("a11").value) : 0;
        var second_number = document.getElementById("b22").value !== "" ? parseInt(document.getElementById("b22").value) : 0;
        var third_number = document.getElementById("c33").value !== "" ? parseInt(document.getElementById("c33").value) : 0;
        var fourth_number = document.getElementById("d44").value !== "" ? parseInt(document.getElementById("d44").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resullt7").value = result;
        var fifth_number = document.getElementById("e11").value !== "" ? parseInt(document.getElementById("e11").value) : 0;
        var sixth_number = document.getElementById("f22").value !== "" ? parseInt(document.getElementById("f22").value) : 0;
        var seventh_number = document.getElementById("g33").value !== "" ? parseInt(document.getElementById("g33").value) : 0;
        var eighth_number = document.getElementById("h44").value !== "" ? parseInt(document.getElementById("h44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resullt8").value = result;
        var fifth_number = document.getElementById("i11").value !== "" ? parseInt(document.getElementById("i11").value) : 0;
        var sixth_number = document.getElementById("j22").value !== "" ? parseInt(document.getElementById("j22").value) : 0;
        var seventh_number = document.getElementById("k33").value !== "" ? parseInt(document.getElementById("k33").value) : 0;
        var eighth_number = document.getElementById("l44").value !== "" ? parseInt(document.getElementById("l44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resullt9").value = result;


        var first_number = document.getElementById("a1.1").value !== "" ? parseInt(document.getElementById("a1.1").value) : 0;
        var second_number = document.getElementById("b2.2").value !== "" ? parseInt(document.getElementById("b2.2").value) : 0;
        var third_number = document.getElementById("c3.3").value !== "" ? parseInt(document.getElementById("c3.3").value) : 0;
        var fourth_number = document.getElementById("d4.4").value !== "" ? parseInt(document.getElementById("d4.4").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resulltt").value = result;
        var fifth_number = document.getElementById("e1.1").value !== "" ? parseInt(document.getElementById("e1.1").value) : 0;
        var sixth_number = document.getElementById("f2.2").value !== "" ? parseInt(document.getElementById("f2.2").value) : 0;
        var seventh_number = document.getElementById("g3.3").value !== "" ? parseInt(document.getElementById("g3.3").value) : 0;
        var eighth_number = document.getElementById("h4.4").value !== "" ? parseInt(document.getElementById("h4.4").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resulltt1").value = result;
        var fifth_number = document.getElementById("i1.1").value !== "" ? parseInt(document.getElementById("i1.1").value) : 0;
        var sixth_number = document.getElementById("j2.2").value !== "" ? parseInt(document.getElementById("j2.2").value) : 0;
        var seventh_number = document.getElementById("k3.3").value !== "" ? parseInt(document.getElementById("k3.3").value) : 0;
        var eighth_number = document.getElementById("l4.4").value !== "" ? parseInt(document.getElementById("l4.4").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resulltt2").value = result;


        var first_number = document.getElementById("a1.11").value !== "" ? parseInt(document.getElementById("a1.11").value) : 0;
        var second_number = document.getElementById("b2.22").value !== "" ? parseInt(document.getElementById("b2.22").value) : 0;
        var third_number = document.getElementById("c3.33").value !== "" ? parseInt(document.getElementById("c3.33").value) : 0;
        var fourth_number = document.getElementById("d4.44").value !== "" ? parseInt(document.getElementById("d4.44").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resulltt3").value = result;
        var fifth_number = document.getElementById("e1.11").value !== "" ? parseInt(document.getElementById("e1.11").value) : 0;
        var sixth_number = document.getElementById("f2.22").value !== "" ? parseInt(document.getElementById("f2.22").value) : 0;
        var seventh_number = document.getElementById("g3.33").value !== "" ? parseInt(document.getElementById("g3.33").value) : 0;
        var eighth_number = document.getElementById("h4.44").value !== "" ? parseInt(document.getElementById("h4.44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resulltt4").value = result;
        var fifth_number = document.getElementById("i1.11").value !== "" ? parseInt(document.getElementById("i1.11").value) : 0;
        var sixth_number = document.getElementById("j2.22").value !== "" ? parseInt(document.getElementById("j2.22").value) : 0;
        var seventh_number = document.getElementById("k3.33").value !== "" ? parseInt(document.getElementById("k3.33").value) : 0;
        var eighth_number = document.getElementById("l4.44").value !== "" ? parseInt(document.getElementById("l4.44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resulltt5").value = result;


       var first_number = document.getElementById("a11.11").value !== "" ? parseInt(document.getElementById("a11.11").value) : 0;
        var second_number = document.getElementById("b22.22").value !== "" ? parseInt(document.getElementById("b22.22").value) : 0;
        var third_number = document.getElementById("c33.33").value !== "" ? parseInt(document.getElementById("c33.33").value) : 0;
        var fourth_number = document.getElementById("d44.44").value !== "" ? parseInt(document.getElementById("d44.44").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resulltt6").value = result;
        var fifth_number = document.getElementById("e11.11").value !== "" ? parseInt(document.getElementById("e11.11").value) : 0;
        var sixth_number = document.getElementById("f22.22").value !== "" ? parseInt(document.getElementById("f22.22").value) : 0;
        var seventh_number = document.getElementById("g33.33").value !== "" ? parseInt(document.getElementById("g33.33").value) : 0;
        var eighth_number = document.getElementById("h44.44").value !== "" ? parseInt(document.getElementById("h44.44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resulltt7").value = result;
        var fifth_number = document.getElementById("i11.11").value !== "" ? parseInt(document.getElementById("i11.11").value) : 0;
        var sixth_number = document.getElementById("j22.22").value !== "" ? parseInt(document.getElementById("j22.22").value) : 0;
        var seventh_number = document.getElementById("k33.33").value !== "" ? parseInt(document.getElementById("k33.333").value) : 0;
        var eighth_number = document.getElementById("l44.44").value !== "" ? parseInt(document.getElementById("l44.44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("resulltt8").value = result;


        var first_number = document.getElementById("m").value !== "" ? parseInt(document.getElementById("m").value) : 0;
        var second_number = document.getElementById("n").value !== "" ? parseInt(document.getElementById("n").value) : 0;
        var third_number = document.getElementById("o").value !== "" ? parseInt(document.getElementById("o").value) : 0;
        var fourth_number = document.getElementById("p").value !== "" ? parseInt(document.getElementById("p").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("resulltt9").value = result;
        var fifth_number = document.getElementById("q").value !== "" ? parseInt(document.getElementById("q").value) : 0;
        var sixth_number = document.getElementById("r").value !== "" ? parseInt(document.getElementById("r").value) : 0;
        var seventh_number = document.getElementById("s").value !== "" ? parseInt(document.getElementById("s").value) : 0;
        var eighth_number = document.getElementById("y").value !== "" ? parseInt(document.getElementById("y").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("total").value = result;
        var fifth_number = document.getElementById("u").value !== "" ? parseInt(document.getElementById("u").value) : 0;
        var sixth_number = document.getElementById("v").value !== "" ? parseInt(document.getElementById("v").value) : 0;
        var seventh_number = document.getElementById("w").value !== "" ? parseInt(document.getElementById("w").value) : 0;
        var eighth_number = document.getElementById("x").value !== "" ? parseInt(document.getElementById("x").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("total1").value = result;


        var first_number = document.getElementById("m1").value !== "" ? parseInt(document.getElementById("m1").value) : 0;
        var second_number = document.getElementById("n2").value !== "" ? parseInt(document.getElementById("n2").value) : 0;
        var third_number = document.getElementById("o3").value !== "" ? parseInt(document.getElementById("o3").value) : 0;
        var fourth_number = document.getElementById("p4").value !== "" ? parseInt(document.getElementById("p4").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("total2").value = result;
        var fifth_number = document.getElementById("q1").value !== "" ? parseInt(document.getElementById("q1").value) : 0;
        var sixth_number = document.getElementById("r2").value !== "" ? parseInt(document.getElementById("r2").value) : 0;
        var seventh_number = document.getElementById("s3").value !== "" ? parseInt(document.getElementById("s3").value) : 0;
        var eighth_number = document.getElementById("t4").value !== "" ? parseInt(document.getElementById("t4").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("total3").value = result;
        var fifth_number = document.getElementById("u1").value !== "" ? parseInt(document.getElementById("u1").value) : 0;
        var sixth_number = document.getElementById("v2").value !== "" ? parseInt(document.getElementById("v2").value) : 0;
        var seventh_number = document.getElementById("w3").value !== "" ? parseInt(document.getElementById("w3").value) : 0;
        var eighth_number = document.getElementById("x4").value !== "" ? parseInt(document.getElementById("x4").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("total4").value = result;

        var first_number = document.getElementById("m11").value !== "" ? parseInt(document.getElementById("m11").value) : 0;
        var second_number = document.getElementById("n22").value !== "" ? parseInt(document.getElementById("n22").value) : 0;
        var third_number = document.getElementById("o33").value !== "" ? parseInt(document.getElementById("o33").value) : 0;
        var fourth_number = document.getElementById("p44").value !== "" ? parseInt(document.getElementById("p44").value) : 0;
        var result = first_number + second_number + third_number + fourth_number;
        document.getElementById("total5").value = result;
        var fifth_number = document.getElementById("q11").value !== "" ? parseInt(document.getElementById("q11").value) : 0;
        var sixth_number = document.getElementById("r22").value !== "" ? parseInt(document.getElementById("r22").value) : 0;
        var seventh_number = document.getElementById("s33").value !== "" ? parseInt(document.getElementById("s33").value) : 0;
        var eighth_number = document.getElementById("t44").value !== "" ? parseInt(document.getElementById("t44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("total6").value = result;
        var fifth_number = document.getElementById("u11").value !== "" ? parseInt(document.getElementById("u11").value) : 0;
        var sixth_number = document.getElementById("v22").value !== "" ? parseInt(document.getElementById("v22").value) : 0;
        var seventh_number = document.getElementById("w33").value !== "" ? parseInt(document.getElementById("w33").value) : 0;
        var eighth_number = document.getElementById("x44").value !== "" ? parseInt(document.getElementById("x44").value) : 0;
        var result = fifth_number + sixth_number + seventh_number + eighth_number;
        document.getElementById("total7").value = result;
      }, 50)
      return true;
    } else {
      return false;
    }
  }
  
  function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }